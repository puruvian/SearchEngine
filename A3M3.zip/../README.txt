### Simple Search Engine

This search engine processes HTML documents to create an inverted index and supports querying with TF-IDF scoring. 
The process is divided into building the index, merging index files, and querying the index using cosine similarity and TF-IDF scores.



### Requirements

- Python 3.x
- NLTK
- BeautifulSoup



### Code Structure

build_index.py: Builds an initial inverted index from HTML documents.

merge.py: Merges multiple index files into a single file for efficient querying.

search.py: Handles the querying logic including calculating TF-IDF and cosine scores.

tokenizer.py: Provides functions for tokenizing text and computing word frequencies.

posting.py: Contains classes for managing document postings.

### How to Build index

To build the index, simply run:

    python build_index


### How to run the search engine:

    Run this in the terminal:
    python3 main.py


This will prompt you to enter a search query and display the results based on the relevance calculated using cosine similarity and TF-IDF scores.